<?php

	/**
	 * Comprehensive Data Validation Class v1.0
	 * 
	 * This class assists in validating user data. The values can be processed 
	 * individually or multiple values of the same type can be processed as an array.
	 * 
	 * This class will validate numbers, strings, dates and times (MySQL format), US
	 * zip codes, IP addresses, MAC addresses, phone numbers, prices (USD), boolean 
	 * values, URLs, email addresses as well as any user defined regular expression. You 
	 * can also compare strings, check string length and check if a number falls within 
	 * a specific range.
	 * 
	 * Values that are submitted to any of the methods can be cleaned prior to testing.
	 * This will remove leading and trailing whitespaces which could cause validation 
	 * failures even though the data itself may be in the correct format. It also allows
	 * you to strip away HTML and PHP tags, decode UTF8 characters and translate HTML 
	 * entities into regular characters. Each of these cleaning options is configurable.
	 * One last cleaning option is the ability to remove slashes that are added to values
	 * if your system happens to have magic quotes enabled. If your system has magic quotes
	 * disabled your data will not be impacted.
	 * 
	 * Each validation method will return a boolean TRUE or FALSE or you can configure it 
	 * to return the "clean" value(s). If clean return is enabled it will return all the 
	 * values after cleaning them ONLY if they all PASS validation, if one of the values 
	 * FAILS validation, a boolean FALSE will be returned.
	 * 
	 * The majority of tests can be tweaked to fit your needs by simply updating any of 
	 * the _regex variables.
	 * 
	 * @author		Brad Glinkerman
	 * @license		GNU General Public License 3 (http://www.gnu.org/licenses/)
	 **/

	class Validate{
		
		// Variable to hold the current regular expression
		
		protected $_regex = NULL;
		
		// Variables to hold cleaning options
		
		protected $_clean           = TRUE;		// Should values be automatically cleaned prior to validating
		protected $_cleanTrim       = TRUE;		// If "_clean" is TRUE, should we remove leading/trailing whitespaces
		protected $_cleanStrip      = TRUE;		// If "_clean" is TRUE, should we remove PHP/HTML tags
		protected $_cleanUTF8Decode = TRUE;		// If "_clean" is TRUE, should we try to decode UTF8 characters
		protected $_cleanHTMLChars  = FALSE;	// If "_clean" is TRUE, should we try to convert special characters to HTML entities
		protected $_cleanReturn     = TRUE;		// If "_clean" is TRUE, should we return the cleaned valued (instead of TRUE) if validation PASSES
		
		// If magic quotes are enabled and you are validating data submitted by a form, it is possible that some tests may fail due to slahses being added into the string automatically, or altered data will be returned with the clean string
		
		protected $_stripSlashes = TRUE;
		
		// Avaliable regular expressions
		
		protected $_regexInt      = "/^-?[0-9]+$/";
		protected $_regexShort    = "/^[a-z0-9-_]+$/";
		protected $_regexAlphaNum = "/^[A-Za-z0-9]+$/";
		protected $_regexBasic    = "/^[A-Za-z0-9-_.,: ]+$/";
		protected $_regexText     = "/^[A-Za-z0-9-_.,?:+=!@#$%&*(){} \/'\"\[\]\|\n\t\r]+$/";
		protected $_regexAllText  = "/^[[:print:]+[:space:]]+$/";
		protected $_regexBoolean  = "/^[01]|yes|no|on|off|true|false$/";
		protected $_regexDate     = "/^(19|20)\d\d-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/";	// 1990 - 2099
		protected $_regexDateTime = "/^(19|20)\d\d-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01]) (0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[1-5][0-9]):(0[0-9]|[1-5][0-9])$/";	// 1990 - 2099
		protected $_regexTimeHMS  = "/^(0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[1-5][0-9]):(0[0-9]|[1-5][0-9])$/";
		protected $_regexTimeHM   = "/^(0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[1-5][0-9])$/";
		protected $_regexMAC      = "/^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$/";
		protected $_regexZip5     = "/^\d{5}$/";
		protected $_regexZip9     = "/(^\d{9}$)|(^\d{5}-\d{4}$)$/";
		protected $_regexPhone    = "/(^1-[2-9]\d{2}-\d{3}-\d{4}$)|(^\d{2}-\d{2}-\d{3}-\d{4}$)/";
		protected $_regexPrice    = "/^-?(\\$)?(\d{1,3}(\,\d{3})*|-?(\\$)?(\d+))(\.\d{2})?$/";
			
		########################################
		##   CUSTOM REGULAR EXPRESSION TEST   ##
		########################################
		
		/**
		 * @desc	Set a custom regular expression for use with the validateRegex() method (good for one use only)
		 * @param   string $Regex The regular expression to use for the custom validation test
		 * @return	boolean Returns TRUE on success or FALSE on error
		 **/
		 
		public function setRegex($RegEx){
			$this->_regex = $RegEx;
			return ($this->_regex == NULL) ? FALSE : TRUE;
		}
		
		/**
		 * @desc	Resets the custom regular expression to NULL (this happens automatically after running the validateRegex() method)
		 * @return	boolean Returns TRUE on success or FALSE on error
		 **/
		 
		protected function resetRegex(){
			$this->_regex = NULL;
			return ($this->_regex == NULL) ? TRUE : FALSE;
		}
		
		/**
		 * @desc	This is a wrapper method used to perform a validation using a regular expression with filter_var().
		 * @param   string|array $Value The value(s) to test
		 * @return	boolean|string Returns TRUE or clean string on success or FALSE on error
		 **/
		 
		public function validateRegex($Value){			
			if($this->_regex != NULL){
				$Result = $this->kickoffFilterVar($Value, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>$this->_regex)));
				$this->resetRegex();
				return $Result;		// Returns clean string/array or TRUE/FALSE depending on _cleanReturn status
			}else{
				return FALSE;
			}			
		}
		
		########################################
		##         WRAPPER FUNCTIONS          ##
		########################################
		
		/**
		 * @desc	Protected method to perform the desired regex check using filter_var() as well as testing string length for those methods that support it
		 * @param   string|array $Value The value(s) to test
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array on success or FALSE on error
		 **/
		 
		protected function kickoffValidateRegex($Value, $Length = NULL, $Operator = NULL){
			if($Length != NULL){			
				$Result = $this->validateRegex($Value);														// Save the cleaned value in casue the user wants to return it if all tests PASS
				if($Result){
					return ($this->validateStringLength($Value, $Length, $Operator)) ? $Result : FALSE;		// If value PASSED both tests, return clean string/array if _cleanReturn is TRUE or return TRUE if _cleanReturn is FALSE; If value FAILS length test return FALSE
				}else{
					return FALSE;																			// Value FAILED test, regadless of _cleanReturn status return FALSE
				}
			}else{
				return $this->validateRegex($Value);														// If _cleanReturn is TRUE, return clean string on PASS or FALSE on FAIL; If _cleanReturn if FALSE return TRUE or FALSE
			}	
		}
		
		/**
		 * @desc	Protected method to perform the desired filter_var() check
		 * @param   string|array $Value The value(s) to test
		 * @param	string $Filter The filter_var() filter to use to validate against
		 * @param	string $FilterOptions [Optional] Additional flags to be used with filter_var()
		 * @return	boolean|string|array Returns TRUE or clean string on success or FALSE on error
		 **/
		
		protected function kickoffFilterVar($Value, $Filter, $FilterOptions = NULL){
			if($this->_clean){ $Value = $this->clean($Value); }
			if($this->_stripSlashes){ $Value = $this->stripSlashes($Value); }
			
			if(is_array($Value)){											// Validate array of values
				$Pass = TRUE;												// Let's assume all values are valid
				foreach($Value as $Current){
					if(!filter_var($Current, $Filter, $FilterOptions)){
						$Pass = FALSE;										// Oops, we found an invalid value, mark as FAILED
					}
				}
				$Result = (!$Pass) ? FALSE : $Value;						// If all values PASS, set $Result to the array of values, otherwise set it to FALSE
			}else{
				$Result = filter_var($Value, $Filter, $FilterOptions);		// Validate single value
			}
			
			if($this->_cleanReturn){
				return $Result;			// _cleanReturn is TRUE, filter_var() returns cleaned string if values passes validation or FALSE if it fails
			}else{
				return (bool) $Result;	// _cleanReturn is FALSE, return boolean TRUE or FALSE
			}
		}
		
		/**
		 * @desc	Protected method to perform the desired preg_match() check (when filter_var() won't cut it)
		 * @param   string|array $Value The value(s) to test
		 * @return	boolean|string|array Returns TRUE or clean string/array on success or FALSE on error
		 **/
		 
		protected function kickoffPregMatch($Value){
			if($this->_clean){ $Value = $this->clean($Value); }
			if($this->_stripSlashes){ $Value = $this->stripSlashes($Value); }

			if(is_array($Value)){								// Validate array of values
				$Pass = TRUE;									// Let's assume all values are valid
				foreach($Value as $Current){
					if(!preg_match($this->_regex, $Current)){
						$Pass = FALSE;							// Oops, we found an invalid value, mark as FAILED
					}
				}
				$Result = (!$Pass) ? FALSE : $Value;			// If all values PASS, set $Result to the array of values, otherwise set it to FALSE
			}else{
				$Result = preg_match($this->_regex, $Value);	// Validate single value
			}
			
			$this->resetRegex();
			
			if($this->_cleanReturn){
				if($Result){
					return $Value;			// _cleanReturn is TRUE and value passes validation, return clean string
				}else{
					return (bool) FALSE;	// _cleanReturn is TRUE and value failed validation, return boolean FALSE
				}
			}else{
				return (bool) $Result;		// _cleanReturn is FALSE, return boolean TRUE or FALSE
			}
		}		
		
		########################################
		##          CLEANUP A VALUE           ##
		########################################
		
		/**
		 * @desc	Set's the clean mode
		 * @param   boolean $Value TRUE to clean strings piror to testing or FALSE to leave strings as-is
		 **/
		 
		public function setCleanMode($Value){
			$this->_clean = $Value;
		}
		
		/**
		 * @desc	Set's the clean options
		 * @param   boolean $Trim Removes leading and trailing whitespace (tabs/spaces/newlines)
		 * @param   boolean $Strip Strips HTML and PHP tags
		 * @param   boolean $UTF8Decode Converts ISO-8859-1 characters encoded with UTF-8 to single-byte ISO-8859-1 characters
		 * @param   boolean $HTMLCharacters Converts HTML entities (ex: '&' becomes '&amp;') back to characters
		 **/
		 
		public function setCleanOptions($Trim = TRUE, $StripTags = TRUE, $UTF8Decode = TRUE, $HTMLCharacters = FALSE){
			$this->_cleanTrim       = $Trim;
			$this->_cleanStrip      = $StripTags;
			$this->_cleanUTF8Decode = $UTF8Decode;
			$this->_cleanHTMLChars  = $HTMLCharacters;
		}
		
		/**
		 * @desc	Set wether or not to return the clean value instead of TRUE (although, if value fails validation FALSE will still be returned)
		 * @param   boolean $Value TRUE to enable or FALSE to disable the returning of clean values
		 **/
		 
		public function setCleanReturnValue($Value){
			if($Value){
				$this->setCleanMode(TRUE);	// If user has not enabled clean mode but wants to return clean values, enable it for them
			}
			$this->_cleanReturn = $Value;
		}
		
		/**
		 * @desc	Cleans-up a value by removing leading and trailing whitespace and/or striping HTML/PHP tags and/or attempting to convert unicdoe characters and/or convert HTML entities to characters
		 * @param   string|array $Value The string/array to clean
		 * @return	string|array The cleaned-up string/array
		 **/
		 
		public function clean($Value){	
			if(is_array($Value)){	// Array of values
				foreach($Value as $Current){
					$Current = ($this->_cleanTrim)       ? trim($Current)                    : $Current;
					$Current = ($this->_cleanStrip)      ? strip_tags($Current)              : $Current;
					$Current = ($this->_cleanUTF8Decode) ? utf8_decode($Current)             : $Current;
					$Current = ($this->_cleanHTMLChars)  ? htmlspecialchars_decode($Current) : $Current;					
					$AllValues[] = $Current;
				}				
				return $AllValues;
			}else{	// Single value
				$Value = ($this->_cleanTrim)       ? trim($Value)             : $Value;
				$Value = ($this->_cleanStrip)      ? strip_tags($Value)       : $Value;
				$Value = ($this->_cleanUTF8Decode) ? utf8_decode($Value)      : $Value;
				$Value = ($this->_cleanHTMLChars)  ? htmlspecialchars($Value) : $Value;				
				return $Value;
			}
		}
		
		/**
		 * @desc	Set's the strip slashes mode
		 * @param   boolean $Value TRUE to remove slashes added by magic quotes or FALSE to leave slashes 
		 **/
		 
		public function setStripSlashesMode($Value){
			$this->_stripSlashes = $Value;
		}
		
		/**
		 * @desc	Strips slashes (added by magic quotes) from a value prior to validating it
		 * @param   string|array $Value TRUE to remove slashes added by magic quotes or FALSE to leave slashes 
		 **/
		 
		protected function stripSlashes($Value){	
			if(get_magic_quotes_gpc()){
				if(is_array($Value)){
					foreach($Value as $Current){
						$AllValues[] = stripslashes($Current);
					}					
					return $AllValues;
				}else{
					return stripslashes($Value);	// Magic quotes is enabled, strip those slashes
				}
			}else{
				return $Value;					// Magic quotes is disabled, no need to strip slashes
			}
		}
		
		########################################
		##          HELPER FUNCTIONS          ##
		########################################
		
		/**
		 * @desc	Determines if the value(s) provided is a valid Gregorian date (date should be in format of YYYY-MM-DD HH:MM:SS, time is optional)
		 * @param   string|array $Value The value(s) to test
		 * @return	boolean Returns TRUE if valid or FALSE if invalid
		 **/
		 
		protected function isValidDate($Value){
			if(is_array($Value)){
				$Pass = TRUE;
				foreach($Value as $Current){
					$TimestampParts = explode(" ", trim($Current));
					$DateParts = explode("-", $TimestampParts[0]);
					if(!checkdate($DateParts[1], $DateParts[2], $DateParts[0])){ $Pass = FALSE; }
				}
				return (bool) $Pass;
			}else{
				$TimestampParts = explode(" ", trim($Value));
				$DateParts = explode("-", $TimestampParts[0]);
				return (bool) checkdate($DateParts[1], $DateParts[2], $DateParts[0]);
			}
		}
		
		/**
		 * @desc	Determines if the two strings/arrays provided are the same. If arrays are given, values are compared in parallel.
		 * @param   string|array $Value1 The value(s) to test
		 * @param   string|array $Value2 The value(s) to test
		 * @return	boolean Returns TRUE if the same or FALSE if different
		 **/
		 
		protected function compareStrings($Value1, $Value2){			
			if(is_array($Value1) && is_array($Value2)){					// Both values are arrays
				if(count($Value1) != count($Value2)){
					return FALSE;										// Both values are arrays but they don't have the same number of elements
				}else{
					$Count = 0;
					$Total = count($Value1);
					$Pass  = TRUE;
					while($Count < $Total){
						if(!strcmp($Value1[$Count], $Value2[$Count]) == 0){		// Compare the corresponding string from each array
							$Pass = FALSE;
						}
						$Count++;
					}
					return $Pass;					
				}
			}elseif(is_array($Value1) || is_array($Value2)){
				return FALSE;											// Only one set is an array, return FALSE
			}else{
				return (strcmp($Value1, $Value2) == 0) ? TRUE : FALSE; 	// Compare two single strings
			}
		}				
							
		########################################
		##      BUILT IN VALIDATION TESTS     ##
		########################################
		
		/**
		 * @desc	Determines if the value provided is an integer (whole number)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateInt($Value){	
			if($this->setRegex($this->_regexInt)){
				return $this->kickoffPregMatch($Value);		// FILTER_VALIDATE_INT returns false if integer is 0
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value provided is a float (decimal number)
		 * @param   string $Value The value to test
		 * @param   boolean $AllowCommans Allow or disallow commas in the float
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateFloat($Value, $AllowCommas = FALSE){	
			$Flag = ($AllowCommas) ? FILTER_FLAG_ALLOW_THOUSAND : NULL;			
			return $this->kickoffFilterVar($Value, FILTER_VALIDATE_FLOAT, $Flag);
		}
		
		/**
		 * @desc	Determines if the value provided is an email address
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateEmail($Value){	
			return $this->kickoffFilterVar($Value, FILTER_VALIDATE_EMAIL);		
		}
		
		/**
		 * @desc	Determines if the value provided is a valid URL
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateURL($Value){	
			return $this->kickoffFilterVar($Value, FILTER_VALIDATE_URL);			
		}
		
		/**
		 * @desc	Determines if the value provided is a valid IPv4 address
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateIPv4($Value){	
			return $this->kickoffFilterVar($Value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);		
		}
		
		/**
		 * @desc	Determines if the value provided is a valid IPv6 address
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/
		 
		public function validateIPv6($Value){	
			return $this->kickoffFilterVar($Value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);		
		}

		/**
		 * @desc	Determines if the value provided is a valid boolean (1, 0, yes, no, on, off, true, false)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateBoolean($Value){	
			if($this->setRegex($this->_regexBoolean)){
				return $this->kickoffPregMatch($Value);
			}else{
				return FALSE;
			}
		}

		/**
		 * @desc	Determines if the value provided is a valid date in the form of YYYY-MM-DD
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateDate($Value){		
			if($this->setRegex($this->_regexDate)){
				if($this->isValidDate($Value)){
					return $this->kickoffValidateRegex($Value);
				}else{
					return FALSE;
				}
			}else{
				return FALSE;
			}
		}

		/**
		 * @desc	Determines if the value provided is a valid date and time in the form of YYYY-MM-DD HH:MM:SS
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateDateTime($Value){		
			if($this->setRegex($this->_regexDateTime)){
				if($this->isValidDate($Value)){
					return $this->kickoffValidateRegex($Value);
				}else{
					return FALSE;
				}						
			}else{
				return FALSE;
			}
		}
	
		/**
		 * @desc	Determines if the value provided is a valid time in the form of HH:MM:SS
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateTimeHMS($Value){		
			if($this->setRegex($this->_regexTimeHMS)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value provided is a valid time in the form of HH:MM
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateTimeHM($Value){		
			if($this->setRegex($this->_regexTimeHM)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
	
		/**
		 * @desc	Determines if the value provided is a valid MAC address (delimited by : or -)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateMAC($Value){		
			if($this->setRegex($this->_regexMAC)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value provided is a valid 5 digit US zip code
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateZip5($Value){		
			if($this->setRegex($this->_regexZip5)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
	
		/**
		 * @desc	Determines if the value provided is a valid 9 digit US zip code (optionally seperated by a -)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateZip9($Value){		
			if($this->setRegex($this->_regexZip9)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
	
		/**
		 * @desc	Determines if the value provided is a valid US or Switzerland phone number with country calling code (delimited by a -)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validatePhone($Value){		
			if($this->setRegex($this->_regexPhone)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value provided is a valid USD price (dolloar with/without cents, optional commas, optional negative sign, optional dollar sign)
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validatePrice($Value){		
			if($this->setRegex($this->_regexPrice)){
				return $this->kickoffValidateRegex($Value);
			}else{
				return FALSE;
			}
		}

		/**
		 * @desc	Determines if the value contains only lowercase characters, numbers 0-9, a dash or an underscore
		 * @param   string $Value The value to test
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateShort($Value, $Length = NULL, $Operator = NULL){		
			if($this->setRegex($this->_regexShort)){				
				return $this->kickoffValidateRegex($Value, $Length, $Operator);			
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value contains only alpha-numeric characters
		 * @param   string $Value The value to test
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateAlphaNum($Value, $Length = NULL, $Operator = NULL){			
			if($this->setRegex($this->_regexAlphaNum)){
				return $this->kickoffValidateRegex($Value, $Length, $Operator);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value contains only uppercase/lowercase characters, spaces, numbers 0-9 or basic punctuation
		 * @param   string $Value The value to test
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateBasic($Value, $Length = NULL, $Operator = NULL){		
			if($this->setRegex($this->_regexBasic)){
				return $this->kickoffValidateRegex($Value, $Length, $Operator);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if the value contains only uppercase/lowercase characters, numbers 0-9, punctuation, spaces, tabs or newlines
		 * @param   string $Value The value to test
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateText($Value, $Length = NULL, $Operator = NULL){		
			if($this->setRegex($this->_regexText)){
				return $this->kickoffValidateRegex($Value, $Length, $Operator);
			}else{
				return FALSE;
			}
		}
			
		/**
		 * @desc	Determines if the value contains any printable or non-printable (spaces, tabs, newline) characters
		 * @param   string $Value The value to test
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 **/

		public function validateAllText($Value, $Length = NULL, $Operator = NULL){		
			if($this->setRegex($this->_regexAllText)){
				return $this->kickoffValidateRegex($Value, $Length, $Operator);
			}else{
				return FALSE;
			}
		}
		
		/**
		 * @desc	Determines if two strings are the same and optionally meet a length requirement
		 * @param   string|array $Value1 The first of two strings/arrays to compare
		 * @param   string|array $Value2 The second of two strings/arrays to compare
		 * @param	integer $Length [Optional] The desired length of the string 
		 * @param	integer $Operator [Optional] The operator to use when testing for string length
		 * @return	boolean|string|array Returns TRUE or clean string/array if valid or FALSE if invalid
		 * @note	You may want to consider disabling cleanMode if comparing password strings
		 **/
		
		public function validateSameString($Value1, $Value2, $Length = NULL, $Operator = NULL){		
			if($this->_clean){ $Value1 = $this->clean($Value1); }
			if($this->_clean){ $Value2 = $this->clean($Value2); }
			if($this->_stripSlashes){ $Value1 = $this->stripSlashes($Value1); }
			if($this->_stripSlashes){ $Value2 = $this->stripSlashes($Value2); }
			
			if($this->compareStrings($Value1, $Value2)){
				if($Length !== NULL){
					if($this->validateStringLength($Value1, $Length, $Operator)){
						if($this->_cleanReturn){
							return $Value1;			// _cleanReturn is TRUE, strings are the same and meet length requirements return clean string
						}else{
							return TRUE;			// _cleanReturn is FALSE, strings are the same and meet length requirements return boolean TRUE
						}						
					}else{
						return FALSE;				// Strings are the same but don't meet length requirements, return FALSE
					}
				}else{
					if($this->_cleanReturn){
						return $Value1;				// _cleanReturn is TRUE, strings are the same return clean string
					}else{
						return TRUE;				// _cleanReturn is FALSE, strings are the same return boolean TRUE
					}
				}
			}else{
				return FALSE;						// Strings are different, return FALSE
			}
		}
		
		/**
		 * @desc	Determines if the string is the correct length
		 * @param   string $Value The value to test
		 * @param   integer $Operator 1 = Equal To, 2 = Greater Than, 3 = Less Than, 4 = Greanter Than or Equal To, 5 = Less Than or Equal To
		 * @return	boolean Returns TRUE if valid or FALSE if invalid
		 **/

		public function validateStringLength($Value, $Length, $Operator = 1){
			if($this->validateInt($Length)){
				if($this->_clean){ $Value = $this->clean($Value); }
				if($this->_stripSlashes){ $Value = $this->stripSlashes($Value); }
				
				if(is_array($Value)){
					$Pass = TRUE;
					foreach($Value as $Current){
						switch($Operator){			
							case 1:
								if(!(strlen($Current) == $Length)){ $Pass = FALSE; }
								break;
							case 2:
								if(!(strlen($Current) > $Length)){ $Pass = FALSE; }
								break;
							case 3:
								if(!(strlen($Current) < $Length)){ $Pass = FALSE; }
								break;
							case 4:
								if(!(strlen($Current) >= $Length)){ $Pass = FALSE; }
								break;
							case 5:
								if(!(strlen($Current) <= $Length)){ $Pass = FALSE; }
								break;
							default:
								if(!(strlen($Current) == $Length)){ $Pass = FALSE; } 
								break;
						}
					}
					return (bool) $Pass;
				}else{				
					switch($Operator){			
						case 1:
							return (bool) (strlen($Value) == $Length) ? TRUE : FALSE; 
							break;
						case 2:
							return (bool) (strlen($Value) > $Length) ? TRUE : FALSE; 
							break;
						case 3:
							return (bool) (strlen($Value) < $Length) ? TRUE : FALSE; 
							break;
						case 4:
							return (bool) (strlen($Value) >= $Length) ? TRUE : FALSE; 
							break;
						case 5:
							return (bool) (strlen($Value) <= $Length) ? TRUE : FALSE; 
							break;
						default:
							return (bool) (strlen($Value) == $Length) ? TRUE : FALSE; 
							break;
					}
				}
				
			}else{
				return FALSE;	// Length passed in was not a valid integer
			}
		}
		
		/**
		 * @desc	Determines if a number is between a minimum and maximum (inclusive)
		 * @param   integer $Value The number to test
		 * @param   integer $Min The minimum number
		 * @param   integer $Max The maximum number
		 * @return	boolean Returns TRUE if between or FALSE if not
		 **/
		 
		public function validateNumberBetween($Value, $Min = 0, $Max = NULL){
			if($this->_clean){ $Value = $this->clean($Value); }
			if($this->validateInt($Value) && $this->validateInt($Min) && $this->validateInt($Max)){
				
				if(is_array($Value)){
					$Pass = TRUE;
					foreach($Value as $Current){
						if(($Current < $Min) || ($Current > $Max)){		// Test each number in the array
							$Pass = FALSE;
						}
					}
					if($Pass){
						if($this->_cleanReturn){
							return $Value;								// _cleanReturn is TRUE, number is between min and max, return clean number
						}else{
							return TRUE;								// _cleanReturn is FALSE, number is between min and max, return boolean TRUE
						}
					}else{
						return FALSE;									// One of the numbers is not between the min and max, return FALSE
					}
				}else{
					if(($Value < $Min) || ($Value > $Max)){
						return FALSE;									// Number is not between min and max, return FALSE
					}else{
						if($this->_cleanReturn){
							return $Value;								// _cleanReturn is TRUE, number is between min and max, return clean number
						}else{
							return TRUE;								// _cleanReturn is FALSE, number is between min and max, return boolean TRUE
						}
					}
				}
				
			}else{
				return FALSE;											// The value, minimum or maximum number provided is not an integer
			}			
		}
		
	}	// END Validate class
	
?>