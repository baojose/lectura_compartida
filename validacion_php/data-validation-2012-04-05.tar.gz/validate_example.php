<?php

	// The below examples are each repeated twice. The first example
	// will simply report valid or invalid, the second example will
	// show what is returnred. The return value will change as you 
	// toggle the setCleanReturnValue() value. You can also toggle 
	// the setCleanMode() value to see how that will affect the results.


	include('Validate.class.php');
	
	$Validate = new Validate();
	$Validate->setCleanMode(TRUE);							// Enable/Disable clean mode (although, its enabled by default)
	$Validate->setCleanOptions(TRUE, TRUE, TRUE, FALSE);	// Turn on/off cleaning options (although, these are the defaults)
	$Validate->setCleanReturnValue(TRUE);					// Enable/Disable returing of clean values
	$Validate->setStripSlashesMode(TRUE);					// If Magic Quotes is enable remove slashes prior to validating data (if Magic Quotes is disabled, nothing will happen)
	
	############################
	##     SINGLE STRINGS     ##
	############################
	
		echo ($Validate->validateDateTime('2012-02-30 23:23:59')) ? "Valid" : "Invalid";			// Invalid because Feb does not have 30 days (even though it is in the correct format)
		
		echo "<br />";
		
		var_dump($Validate->validateDateTime('2012-02-30 23:23:59'));
		
		echo "<br /><br />";
		
		echo ($Validate->validateInt("0") !== FALSE) ? "Valid" : "Invalid";			// Valid because 0 is an integer
		
		echo "<br />";
		
		var_dump($Validate->validateInt("0"));
		
		echo "<br /><br />";
		
		echo ($Validate->validateEmail("php@gmail.com") !== FALSE) ? "Valid" : "Invalid";			// Valid because its is a valid email address
		
		echo "<br />";
		
		var_dump($Validate->validateEmail("php@gmail.com")); 
		
		echo "<br /><br />";
		
		echo ($Validate->validateFloat("10,000.2", TRUE) !== FALSE) ? "Valid" : "Invalid";			// Valid because it is a float and we are allowing commas
		
		echo "<br />";
		
		var_dump($Validate->validateFloat("10,000.2", TRUE));	
		
		echo "<br /><br />";
		
		echo ($Validate->validateFloat("  1.2 ") !== FALSE) ? "Valid" : "Invalid";			// Valid because clean mode is TRUE
		
		echo "<br />";
		
		var_dump($Validate->validateFloat("  1.2 "));
			
		echo "<br /><br />";
		
		$Validate->setRegex("/google|facebook|twitter/");							// Using custom regular expression
		echo ($Validate->validateRegex("facebook")) ? "Valid" : "Invalid";			// Valid because string matches custom regular expression
		
		echo "<br />";
		
		$Validate->setRegex("/google|facebook|twitter/");
		var_dump($Validate->validateRegex("facebook"));

		echo "<br /><br />";
		
		echo ($Validate->validateStringLength("This is a test", 5, 1)) ? "Valid" : "Invalid";			// Invalid because string length does not equal 5
		
		echo "<br />";
		
		var_dump($Validate->validateStringLength("This is a test", 5, 1));

		echo "<br /><br />";
		
		echo ($Validate->validateStringLength("This is a test", 5, 2)) ? "Valid" : "Invalid";			// Valid because string length is greater than 5
		
		echo "<br />";
		
		var_dump($Validate->validateStringLength("This is a test", 5, 2));
		
		echo "<br /><br />";
		
		echo ($Validate->validateBasic("This is a test")) ? "Valid" : "Invalid";			// Valid because string contains only characters found in the basic regex
		
		echo "<br />";
		
		var_dump($Validate->validateBasic("This is a test"));

		echo "<br /><br />";
		
		echo ($Validate->validateBasic(" This is a test ", 5, 1)) ? "Valid" : "Invalid";			// Invalid because string length does not equal five (even though it contains only characters found in the basic regex)
		
		echo "<br />";
		
		var_dump($Validate->validateBasic(" This is a test ", 5, 1));

		echo "<br /><br />";

		echo ($Validate->validatePrice("-$1,000,000.00")) ? "Valid" : "Invalid";			// Valid because it matches the criteria of the price regex
		
		echo "<br />";
		
		var_dump($Validate->validatePrice("-$1,000,000.00"));
		
		echo "<br /><br />";
		
		echo ($Validate->validateBoolean("   0  ") !== FALSE) ? "Valid" : "Invalid";			// Valid because clean mode is TRUE
		
		echo "<br />";
		
		var_dump($Validate->validateBoolean("   0  "));
		
		echo "<br /><br />";
		
		$Text = "This is a long
				paragraph to verify		that the 
				AllText filter accepts tabs		and 
				newlines";
		echo ($Validate->validateAllText($Text)) ? "Valid" : "Invalid";			// Valid because all characters are allowed
		
		echo "<br />";
		
		echo "<pre>"; var_dump($Validate->validateAllText($Text)); echo "</pre>";

		echo "<br /><br />";
		
		$Validate->setCleanMode(FALSE);
		echo ($Validate->validateBoolean("   0 ")) ? "Valid" : "Invalid";			// Invalid because clean mode is FALSE
		
		echo "<br />";
		
		var_dump($Validate->validateBoolean("   0 "));
		
		echo "<br /><br />";
		
		$Validate->setCleanMode(TRUE);
		echo ($Validate->validateSameString("myPazzWo4d", "myPazzwo4d")) ? "Valid" : "Invalid";			// Invalid because strings are different by one character
		
		echo "<br />";	
		
		var_dump($Validate->validateSameString("myPazzWo4d", "myPazzwo4d"));
		
		echo "<br /><br />";
		
		echo ($Validate->validateSameString("myPazzWo4d", "myPazzWo4d", 8, 4)) ? "Valid" : "Invalid";			// Valid because strings are the same and meet the length requirements by one character
		
		echo "<br />";	
		
		var_dump($Validate->validateSameString("myPazzWo4d", "myPazzWo4d", 8, 4));
		
		echo "<br /><br />";
		
	############################
	##         ARRAYS         ##
	############################
	
		$Validate->setCleanReturnValue(TRUE);
		
		echo ($Validate->validateInt(array(234,24,3,1,2,4,63,32,423)) !== FALSE) ? "Valid" : "Invalid";			// Valid because entire array contains integers
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateInt(array(234,24,3,1,2,4,63,32,423))); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateFloat(array("1x.2","9.0","253.3","59.66")) !== FALSE) ? "Valid" : "Invalid";			// Invalid because one value has a character
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateFloat(array("1x.2","9.0","253.3","59.66"))); echo "</pre>";
		
		echo "<br /><br />";

		echo ($Validate->validateURL(array("https://www.msn.com", "http://www.google.co", "ftp://www.yahoo.biz")) !== FALSE) ? "Valid" : "Invalid";			// Valid because are all URLS
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateURL(array("https://www.msn.de", "http://www.google.com", "ftp://www.yahoo.biz"))); echo "</pre>";
		
		echo "<br /><br />";
	
		echo ($Validate->validateBoolean(array(1, 0, "on", "off", "yes", "no", "true", "false")) !== FALSE) ? "Valid" : "Invalid";			// Valid because are values are possible booleans
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateBoolean(array(1, 0, "on", "off", "yes", "no", "true", "false"))); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateTimeHM(array("12:00", "13:36", "00:41", "23:60"))) ? "Valid" : "Invalid";			// Invalid because 60 is an invalid minute
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateTimeHM(array("12:00", "13:36", "00:41", "23:60"))); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateStringLength(array("cat", "dog", "bird", "rabbit"), 3, 4)) ? "Valid" : "Invalid";			// Valid because all strings are greater than or equal to 3
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateStringLength(array("cat", "dog", "bird", "rabbit"), 3, 4)); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateShort(array("1cat", "3dog", "bird", "rabbit"), 3, 4)) ? "Valid" : "Invalid";			// Valid because all strings are greater than or equal to 3 AND contain lowercase characters and digits
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateShort(array("1cat", "3dog", "bird", "rabbit"), 3, 4)); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateDate(array("2012-02-29", "2011-06-23", "2010-10-20"))) ? "Valid" : "Invalid";			// Valid because all dates are actual dates
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateDate(array("2012-02-29", "2011-06-23", "2010-10-20"))); echo "</pre>";
		
		echo "<br /><br />";
		
		echo ($Validate->validateSameString(array(" string1 ", "string2  ", "string3"), array("string1", " string2", "string3"), 5, 2)) ? "Valid" : "Invalid";			// Valid because the values in the parallel array are the same AND each string is greater than 5 characters AND we are cleaning the values prior to validating
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateSameString(array(" string1 ", "string2  ", "string3"), array("string1", " string2", "string3"), 5, 2)); echo "</pre>";
		
		echo "<br /><br />";
	
		echo ($Validate->validateNumberBetween(array(-10, 52, 854), -50, 1000)) ? "Valid" : "Invalid";			// Valid because the values are between -50 and 1000
		
		echo "<br />";	
		
		echo "<pre>"; var_dump($Validate->validateNumberBetween(array(-10, 52, 854), -50, 1000)); echo "</pre>";
		
		echo "<br /><br />";
?>